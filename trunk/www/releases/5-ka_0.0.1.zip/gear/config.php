<?

$_cfg['www'] 			= 'http://5-ka.net';
$_cfg['title'] 			= '5-ka blog';
$_cfg['author'] 		= 'Eugene Che';
$_cfg['email'] 			= 'name@domen.tld';
$_cfg['login']			= 'admin';
$_cfg['pass']			= '21232f297a57a5a743894a0e4a801fc3'; // admin
$_cfg['decsription']	= '5-ka: atomic blog without SQL';
$_cfg['keywords'] 		= 'php, blog-cms-engine, flat-file, no-mysql, blog-engine, open source';
$_cfg['theme'] 			= 'nano';
$_cfg['articlesperpage']= '10';

$_paginator['flag']		= 2 // 0 - empty 1 - no prev 2 - no more

?>