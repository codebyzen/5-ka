		<DL class="post">
			<H2>§ <?=$_article['url_title'];?></H2>
			<DIV>
			<?=$_article['text'];?>
			</DIV>
			<DIV>
				<?=$_article['full'];?>
				<?=$_article['time'];?> by <?=$_cfg['author'];?>
			</DIV>
		</DL>