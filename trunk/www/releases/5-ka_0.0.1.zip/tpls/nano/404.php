		<DL class="post">
			<H2>Sorry 404 page =(</H2>зачем порвал?<br>хватит уже тут тыкать куда не следует!
			<DIV style="text-align:center;">
				<img src="<?=$_cfg['www'];?>/tpls/<?=$_cfg['theme'];?>/404.jpg">
			</DIV>
		</DL>
